# SURFEELA Supabase migration starter

This is a **Next.js integration starter**, not a finished migration of the existing standalone HTML file. It includes safer Supabase helpers, session-refresh middleware, an atomic checkout server action, and a database migration.

## Setup
1. Create a Next.js App Router TypeScript project.
2. Install dependencies: `npm install @supabase/supabase-js @supabase/ssr`
3. Copy `.env.local.example` to `.env.local` (the provided publishable key is public by design; never add a service-role key to client code).
4. Copy `src/utils`, `src/middleware.ts`, and `src/app/actions/orders.ts` into your project. If your project does not use a `src/` directory, move `src/middleware.ts` to the project root and adjust the alias if needed.
5. Run `supabase/migrations/001_core.sql` in the Supabase SQL Editor.
6. Create an admin user in Supabase Auth, then insert its UUID into `public.admins` using the SQL Editor.
7. Add `@/*` path alias in `tsconfig.json` if the starter project doesn't already include it.

## Security and limitations
- Checkout uses a PostgreSQL function to calculate prices and delivery fee from database values and deduct stock in the same transaction. The browser does not send trusted prices.
- This starter does not yet include the full Storefront, customer portal, all admin CRUD pages, storage upload UI, audit log, payment gateway, rate limiting, or comprehensive tests.
- Admin and customer access still require testing with actual Supabase Auth users and RLS policies before production use.
- For production, add rate limiting, spam protection, audit logs, idempotency keys, order-status transition rules, image bucket policies, and automated tests.
- Seed rows are demo catalogue values; verify prices and stock before making the store public.
