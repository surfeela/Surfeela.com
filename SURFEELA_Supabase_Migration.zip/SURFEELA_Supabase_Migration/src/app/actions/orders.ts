"use server";

import { createClient } from "@/utils/supabase/server";
import { revalidatePath } from "next/cache";

export type CheckoutItem = { productId: number; quantity: number };

/** Server/database calculate all prices, delivery, totals and stock changes. */
export async function placeOrder(input: {
  customer_name: string;
  phone: string;
  address: string;
  city: string;
  notes?: string;
  payment_method: "Cash on Delivery" | "Easypaisa on delivery";
  items: CheckoutItem[];
}) {
  const name = input.customer_name.trim();
  const phone = input.phone.replace(/[\s()-]/g, "");
  const address = input.address.trim();
  if (name.length < 3) throw new Error("Enter your full name.");
  if (!/^03\d{9}$/.test(phone)) throw new Error("Enter a valid Pakistani mobile number.");
  if (address.length < 12) throw new Error("Enter a complete delivery address.");
  if (!input.city.trim()) throw new Error("Choose a delivery city.");
  if (!input.items.length || input.items.length > 50) throw new Error("Your cart is empty or contains too many items.");
  if (!input.items.every((i) => Number.isSafeInteger(i.productId) && i.productId > 0 && Number.isSafeInteger(i.quantity) && i.quantity > 0 && i.quantity <= 100)) {
    throw new Error("One or more cart quantities are invalid.");
  }
  const combined = new Map<number, number>();
  for (const item of input.items) combined.set(item.productId, (combined.get(item.productId) ?? 0) + item.quantity);
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("place_surfeela_order", {
    p_customer_name: name,
    p_phone: phone,
    p_address: address,
    p_city: input.city,
    p_notes: (input.notes ?? "").trim().slice(0, 1000),
    p_payment_method: input.payment_method,
    p_items: [...combined.entries()].map(([product_id, quantity]) => ({ product_id, quantity })),
  });
  if (error) throw new Error(error.message);
  revalidatePath("/");
  revalidatePath("/customer");
  revalidatePath("/admin");
  return { id: String(data) };
}
