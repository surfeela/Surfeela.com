"use server";
import { createClient } from "@/utils/supabase/server";
import { revalidatePath } from "next/cache";

type Item = { productId: number; quantity: number };
export async function placeOrder(input: {
  customer_name: string; phone: string; address: string; city: string;
  payment_method: "Cash on Delivery" | "Easypaisa on delivery"; notes?: string; items: Item[];
}) {
  const supabase = await createClient();
  if (!Array.isArray(input.items) || input.items.length === 0) throw new Error("Cart is empty.");
  const phone = input.phone.replace(/[\s()-]/g, "");
  const { data, error } = await supabase.rpc("place_order", {
    p_customer_name: input.customer_name.trim(), p_phone: phone,
    p_address: input.address.trim(), p_city: input.city,
    p_payment_method: input.payment_method, p_notes: input.notes ?? "",
    p_items: input.items.map(i => ({ productId: i.productId, quantity: i.quantity })),
  });
  if (error) throw new Error(error.message);
  revalidatePath("/");
  return { id: data as string };
}
