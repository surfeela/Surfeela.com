# SURFEELA Next.js + Supabase migration starter

This package provides Supabase browser/server clients, session-refresh middleware, a migration schema, and a server action that calls an atomic database checkout function. It is a starter kit, not a complete port of the existing standalone HTML website.

## 1. Create app and install dependencies

```bash
npx create-next-app@latest surfeela --typescript --app --no-tailwind --src-dir
cd surfeela
npm install @supabase/supabase-js @supabase/ssr
```

Copy the `src/` and `supabase/` files from this package into that project. Copy `.env.local.example` to `.env.local`. Restart the dev server after setting env vars.

## 2. Apply database migration

Open Supabase SQL Editor and run `supabase/migrations/0001_initial.sql`. Review it first if the project already contains tables/policies. This migration is designed for a new schema and is not a general-purpose merge migration.

## 3. Create the first admin

1. Create a user under Supabase Authentication.
2. Copy that user's UUID.
3. Run `insert into public.admins(user_id, role) values ('YOUR-UUID-HERE','owner');` in SQL Editor.
4. Do not expose admin creation in public UI.

## 4. Use the checkout action

Call `placeOrder` from a client component with item IDs and quantities only. The SQL function gets product names/prices and delivery fees from the database, locks stock rows, deducts inventory and creates the order in one transaction. Do not send a client-calculated price as authoritative data.

## Important limitations

- This does not automatically port the old HTML's UI or every admin/customer page. Those pages must be built and connected to these tables/actions.
- The SQL seed catalog from the supplied draft was intentionally omitted because those sample prices/stock values may not reflect actual SURFEELA inventory.
- `is_admin()` is a basic admin membership check; role-specific permissions still need policy design before production.
- Admin order-status updates must be implemented with transactional stock restoration and status-transition validation. Do not use the draft's public `decrement_stock` RPC.
- Set up Supabase Storage buckets and upload policies separately before adding image uploads.
- Run `npm run build`, test RLS with anonymous/customer/admin accounts, and verify checkout races before production deployment.
- The publishable key is intended for public client configuration. Never add a service-role key to `.env.local` under a `NEXT_PUBLIC_` name or expose it in browser code.
