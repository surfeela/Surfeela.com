# ChatWave Starter

A mobile-first HTML/CSS/JavaScript messaging UI prototype with a planned custom backend.

## What works in this prototype
- Responsive chat interface for Android-sized screens
- Demo phone-number login with a locally generated code (NOT real SMS/OTP)
- Local demo conversations saved in browser localStorage
- New local demo chats
- Message composer and sample sent/delivered ticks
- Local image attachment preview
- Voice/video/group call screens; video mode can request a local camera preview
- Profile name editing and logout

## What is NOT connected yet
- Real SMS/phone OTP verification
- Real messaging between different users/devices
- Real server-side accounts and database
- Push notifications, real online/last-seen presence, and delivery receipts
- WebRTC calls, remote video, group-call media routing
- End-to-end encryption

Do not use the local demo OTP or localStorage as production authentication or storage.

## Open the front end
Open `index.html` in a browser. Some browser features such as camera access usually require HTTPS or localhost.

## Suggested custom backend
- Node.js + Express for REST endpoints
- Socket.IO or WebSocket for live messages, presence and call signaling
- PostgreSQL for users, conversations, participants, messages, call records and device sessions
- An SMS OTP provider for real verification
- Object storage for image/video/voice uploads
- WebRTC for audio/video, plus STUN/TURN; group calling normally needs an SFU media server
- Push notification integration for Android incoming messages/calls

## Recommended implementation sequence
1. Build backend authentication endpoints using a real SMS OTP provider. Rate-limit OTP requests and attempts.
2. Use verified phone numbers to create server-side user IDs. Never trust a client-supplied user ID.
3. Add conversation and membership tables. Check membership on every read/send action.
4. Add persistent messages through REST/database and live delivery through Socket.IO.
5. Add server-side delivery/read receipts and presence.
6. Add protected media upload/download.
7. Add WebRTC signaling and TURN; add an SFU for group calls.
8. Build/package an Android client (for example, Capacitor or a native Android app) and integrate push notifications.
9. Security review and multi-device/offline testing before public launch.

## Database starter
See `schema.sql` for a PostgreSQL starting schema. It is a schema draft, not a complete production deployment.

## Security reminders
- Use HTTPS in production.
- Never store passwords, OTPs, access tokens, or private keys in localStorage.
- Store only hashed OTP challenges server-side, with short expiry and attempt limits.
- Keep database credentials and SMS provider keys on the server, never in front-end JavaScript.
- Enforce authorization server-side for chats, messages, media, and calls.
- If you need WhatsApp-style end-to-end encryption, use a reviewed protocol/library; do not invent your own cryptography.
