/* ChatWave front-end prototype.
   Local demo only: OTP, delivery, presence and calls are simulated.
   Connect the documented backend before using with real users. */
const $ = (id) => document.getElementById(id);
const STORE_KEY = "chatwave_demo_v1";
const initialChats = [
  { id:"chat-demo-1", name:"Ahmad Khan", phone:"+92 300 1112233", online:true, messages:[
    {id:"m1",from:"them",text:"Hi! Welcome to ChatWave.",time:"09:40",status:"read"},
    {id:"m2",from:"me",text:"Hello Ahmad. How are you?",time:"09:41",status:"read"},
    {id:"m3",from:"them",text:"I am good. This is a sample conversation.",time:"09:42",status:"read"}
  ]},
  { id:"chat-demo-2", name:"Sara Ali", phone:"+92 301 5556677", online:false, lastSeen:"last seen recently", messages:[
    {id:"m4",from:"them",text:"We can test the chat layout here.",time:"Yesterday",status:"read"}
  ]},
  { id:"chat-demo-3", name:"Family Group", phone:"3 participants", online:true, group:true, messages:[
    {id:"m5",from:"them",text:"Group chats will be connected to the backend later.",time:"Yesterday",status:"read"}
  ]}
];
let state = { user:null, chats:initialChats, activeChatId:null, callType:null, stream:null, muted:false };
let toastTimer;

function loadState(){
  try {
    const saved = JSON.parse(localStorage.getItem(STORE_KEY) || "null");
    if(saved && Array.isArray(saved.chats)) state.chats = saved.chats;
    if(saved && saved.user) state.user = saved.user;
  } catch(e) { console.warn("Could not load demo state", e); }
}
function saveState(){
  try { localStorage.setItem(STORE_KEY, JSON.stringify({user:state.user,chats:state.chats})); }
  catch(e){ showToast("Storage is full. Some changes may not be saved."); }
}
function escapeHTML(value){
  return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[ch]));
}
function showToast(message){
  const el=$("toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2600);
}
function initials(name){ return (name||"?").trim().split(/\s+/).slice(0,2).map(p=>p[0]||"").join("").toUpperCase(); }
function timeNow(){ return new Intl.DateTimeFormat([], {hour:"2-digit",minute:"2-digit"}).format(new Date()); }
function showLogin(){
  $("loginScreen").classList.remove("hidden"); $("chatApp").classList.add("hidden");
  $("phoneForm").classList.remove("hidden"); $("otpForm").classList.add("hidden"); $("loginError").textContent="";
}
function showApp(){
  $("loginScreen").classList.add("hidden"); $("chatApp").classList.remove("hidden");
  $("currentUserLabel").textContent=state.user.name || state.user.phone;
  $("displayNameInput").value=state.user.name || "";
  renderChatList();
  if(state.activeChatId) openChat(state.activeChatId); else showEmpty();
}
function renderChatList(){
  const q=$("searchInput").value.trim().toLowerCase();
  const list=$("chatList");
  const filtered=state.chats.filter(c=>(c.name+" "+c.phone+" "+(c.messages.at(-1)?.text||"")).toLowerCase().includes(q));
  list.innerHTML=filtered.map(c=>{
    const last=c.messages[c.messages.length-1];
    return `<div class="contact-row ${state.activeChatId===c.id?"selected":""}" data-chat-id="${escapeHTML(c.id)}" role="button" tabindex="0">
      <div class="avatar">${escapeHTML(initials(c.name))}</div>
      <div class="contact-info"><div class="contact-top"><strong>${escapeHTML(c.name)}</strong><time>${escapeHTML(last?.time||"")}</time></div>
      <div class="last-message">${escapeHTML(last?.text || (c.group?"Group conversation":"Start a conversation"))}</div></div>
    </div>`;
  }).join("") || `<p class="muted" style="padding:18px">No chats found.</p>`;
  list.querySelectorAll("[data-chat-id]").forEach(el=>{
    el.addEventListener("click",()=>openChat(el.dataset.chatId));
    el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openChat(el.dataset.chatId);}});
  });
}
function showEmpty(){
  $("emptyState").classList.remove("hidden"); $("activeChat").classList.add("hidden");
  $("chatApp").classList.remove("mobile-chat-open");
}
function openChat(id){
  const chat=state.chats.find(c=>c.id===id); if(!chat) return;
  state.activeChatId=id;
  $("emptyState").classList.add("hidden"); $("activeChat").classList.remove("hidden");
  $("chatApp").classList.add("mobile-chat-open");
  $("chatName").textContent=chat.name; $("chatAvatar").textContent=initials(chat.name);
  $("chatPresence").textContent=chat.online?"Online":(chat.lastSeen||"Offline");
  $("typingIndicator").classList.add("hidden");
  $("callBanner").classList.add("hidden");
  renderMessages(); renderChatList();
}
function renderMessages(){
  const chat=state.chats.find(c=>c.id===state.activeChatId); if(!chat) return;
  const box=$("messages");
  box.innerHTML=chat.messages.map(m=>{
    const outgoing=m.from==="me";
    const body=m.image ? `<img class="message-image" src="${m.image}" alt="Shared image"><div>${escapeHTML(m.text||"Photo")}</div>` : escapeHTML(m.text);
    const tick=outgoing?`<span class="message-status">${m.status==="read"?"✓✓":m.status==="delivered"?"✓✓":"✓"}</span>`:"";
    return `<div class="message-row ${outgoing?"outgoing":""}"><div class="message-bubble">${body}</div><div class="message-meta"><time>${escapeHTML(m.time)}</time>${tick}</div></div>`;
  }).join("");
  box.scrollTop=box.scrollHeight;
}
function addMessage(text, imageData=null){
  const chat=state.chats.find(c=>c.id===state.activeChatId); if(!chat) return;
  chat.messages.push({id:"msg-"+Date.now()+"-"+Math.random().toString(16).slice(2,7),from:"me",text,time:timeNow(),status:"sent",image:imageData});
  saveState(); renderMessages(); renderChatList();
  // Demo acknowledgement only. A real server must issue delivery/read receipts.
  setTimeout(()=>{
    const msg=chat.messages.at(-1);
    if(msg && msg.from==="me" && msg.status==="sent"){msg.status="delivered";saveState();renderMessages();}
  },800);
}
function startNewChat(){
  if(typeof $("newChatDialog").showModal==="function") $("newChatDialog").showModal();
  else showToast("Your browser does not support this dialog.");
}
function createChat(name,phone){
  const normalized=phone.replace(/\s+/g," ").trim();
  let chat=state.chats.find(c=>c.phone===normalized);
  if(chat){openChat(chat.id);showToast("This demo chat already exists.");return;}
  chat={id:"chat-"+crypto.randomUUID(),name,phone:normalized,online:false,messages:[]};
  state.chats.unshift(chat);saveState();renderChatList();openChat(chat.id);showToast("Local demo chat created.");
}
function startCall(type){
  const chat=state.chats.find(c=>c.id===state.activeChatId); if(!chat) return;
  state.callType=type; state.muted=false;
  $("callAvatar").textContent=initials(chat.name); $("callContactName").textContent=chat.name;
  $("callTypeLabel").textContent=type==="video"?"Video call":type==="group"?"Group call":"Voice call";
  $("callStatus").textContent=type==="group"?"Preparing group call…":"Calling…";
  $("videoPreviewWrap").classList.toggle("hidden",type!=="video");
  $("cameraButton").classList.toggle("hidden",type!=="video");
  $("muteButton").textContent="♬";
  $("callBanner").textContent=`${type==="video"?"Video":type==="group"?"Group":"Voice"} call started in demo mode. Live calling is not connected.`;
  $("callBanner").classList.remove("hidden");
  if(typeof $("callDialog").showModal==="function") $("callDialog").showModal();
  showToast("Demo call screen opened.");
  if(type==="video") startLocalVideoPreview();
}
async function startLocalVideoPreview(){
  try{
    if(!navigator.mediaDevices?.getUserMedia) throw new Error("Camera not supported");
    state.stream=await navigator.mediaDevices.getUserMedia({video:true,audio:true});
    $("localVideo").srcObject=state.stream;
    $("callStatus").textContent="Camera preview only — no remote caller connected";
  }catch(e){ $("callStatus").textContent="Camera permission not available. Demo call only."; }
}
function endCall(){
  if(state.stream){state.stream.getTracks().forEach(t=>t.stop());state.stream=null;}
  $("localVideo").srcObject=null;
  if($("callDialog").open) $("callDialog").close();
  state.callType=null;
  showToast("Demo call ended.");
}
function logout(){
  state.user=null;state.activeChatId=null;saveState();showLogin();
}
$("phoneForm").addEventListener("submit",e=>{
  e.preventDefault();
  const digits=$("phoneInput").value.replace(/\D/g,"");
  if(digits.length!==10){$("loginError").textContent="Enter a 10-digit mobile number after +92.";return;}
  state.pendingPhone="+92 "+digits;
  state.demoOtp=String(Math.floor(100000+Math.random()*900000));
  $("phoneForm").classList.add("hidden");$("otpForm").classList.remove("hidden");
  $("otpHint").textContent=`Demo verification code: ${state.demoOtp}. Real SMS is not connected.`;
  $("loginError").textContent="";$("otpInput").focus();
});
$("otpForm").addEventListener("submit",e=>{
  e.preventDefault();
  if($("otpInput").value.trim()!==state.demoOtp){$("loginError").textContent="Incorrect demo code. Try the code shown above.";return;}
  state.user={id:"user-"+state.pendingPhone.replace(/\D/g,""),phone:state.pendingPhone,name:"You"};
  saveState();showApp();showToast("Demo login successful.");
});
$("changePhoneButton").addEventListener("click",()=>{ $("otpForm").classList.add("hidden");$("phoneForm").classList.remove("hidden");$("otpInput").value="";$("loginError").textContent="";});
$("messageForm").addEventListener("submit",e=>{
  e.preventDefault();const text=$("messageInput").value.trim();if(!text)return;
  addMessage(text);$("messageInput").value="";$("messageInput").focus();
});
$("searchInput").addEventListener("input",renderChatList);
$("newChatButton").addEventListener("click",startNewChat);
$("emptyNewChatButton").addEventListener("click",startNewChat);
$("newChatForm").addEventListener("submit",e=>{
  e.preventDefault();const name=$("contactNameInput").value.trim(),phone=$("contactPhoneInput").value.trim();
  if(!name||!phone)return;
  $("newChatDialog").close();createChat(name,phone);$("newChatForm").reset();
});
$("backButton").addEventListener("click",()=>{state.activeChatId=null;showEmpty();renderChatList();});
$("voiceCallButton").addEventListener("click",()=>startCall("voice"));
$("videoCallButton").addEventListener("click",()=>startCall("video"));
$("groupCallButton").addEventListener("click",()=>{
  const chat=state.chats.find(c=>c.id===state.activeChatId);
  if(!chat?.group){showToast("Open a group chat first. You can create one in a future backend version.");return;}
  startCall("group");
});
$("endCallButton").addEventListener("click",endCall);
$("muteButton").addEventListener("click",()=>{
  state.muted=!state.muted;
  if(state.stream) state.stream.getAudioTracks().forEach(t=>t.enabled=!state.muted);
  $("muteButton").textContent=state.muted?"Mic off":"♬";
  $("callStatus").textContent=state.muted?"Microphone muted in local preview":"Demo call — no remote caller connected";
});
$("cameraButton").addEventListener("click",()=>{
  if(!state.stream){showToast("Camera preview is not active.");return;}
  const tracks=state.stream.getVideoTracks();const enabled=tracks.some(t=>t.enabled);
  tracks.forEach(t=>t.enabled=!enabled);showToast(enabled?"Camera turned off":"Camera turned on");
});
$("attachButton").addEventListener("click",()=>$("attachmentInput").click());
$("attachmentInput").addEventListener("change",e=>{
  const file=e.target.files?.[0];if(!file)return;
  if(!file.type.startsWith("image/")){showToast("Choose an image file.");return;}
  if(file.size>3*1024*1024){showToast("Demo image limit is 3 MB.");e.target.value="";return;}
  const reader=new FileReader();reader.onload=()=>{addMessage(file.name,String(reader.result));e.target.value="";};reader.readAsDataURL(file);
});
$("profileButton").addEventListener("click",()=>{
  if(!state.user){showToast("Log in first.");return;}
  $("displayNameInput").value=state.user.name||"";
  $("profileDialog").showModal();
});
$("saveProfileButton").addEventListener("click",e=>{
  e.preventDefault();if(!state.user)return;
  state.user.name=$("displayNameInput").value.trim()||"You";saveState();$("profileDialog").close();showApp();showToast("Profile saved on this device.");
});
$("logoutButton").addEventListener("click",logout);
loadState();
if(state.user) showApp(); else showLogin();
